from django.contrib import admin
from django.urls import path
from myapp import views

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', views.home, name='home'),
    path('about.html/', views.about, name='about'),
    path('hobby.html/', views.hobby, name='hobby'),
    path('music.html/', views.music, name='music'),
    path('photo.html/', views.photo, name='photo'),
    path('location.html/', views.location, name='location'),

    path('new/', views.new, name='new'),
    path('crate/', views.create, name='create'),
    

]

from django.shortcuts import render, redirect
from .models import Blog
from django.utils import timezone


# Create your views here.
def home(request):
    posts=Blog.objects.all()
    return render(request, 'index.html', {'posts':posts})

def about(request):
    return render(request, 'about.html')

def hobby(request):
    return render(request, 'hobby.html')

def music(request):
    return render(request, 'music.html')

def photo(request):
    return render(request, 'photo.html')

def location(request):
    return render(request, 'location.html')

def new(request):
    return render(request, 'new.html')

def create(request):
    if(request.method=='POST'):
        post=Blog()
        post.title=request.POST['title']
        post.body=request.POST['body']
        post.date=timezone.now()
        post.save()
    return redirect('home')
